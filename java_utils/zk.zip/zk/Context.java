/**
 * 
 */
package com.yuntongxun.common.zk;

/**
 * @author chao
 */
public abstract class Context {

	/**
	 * windows support ?
	 */
	public static final String SEPARATOR = "/";

	public static final String ZK_ROOT_NODE_PATH = "/ai";

    public static final String GROUP_ID = "/default";

	public static final String ZK_AI_PATH = "/ai/default/YTX_AI_QUEUE/";
}
